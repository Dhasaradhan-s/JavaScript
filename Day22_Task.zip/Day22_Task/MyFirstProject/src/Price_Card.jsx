import React from 'react'
import './Price_Card.css'

function Price_Card() {

  return  React.createElement('div',{className:"container d-flex  justify-content-around p-1 m-1 b"},


          //card-1

          React.createElement('div',{id:'item1',className:'card p-0 m-0 '},
          
          // header

            React.createElement('div',{className:'card-header p-3 bg-white'}, 
            React.createElement('div',{id:'h-txt-sm'},"FREE"),
            React.createElement('div',{id:'h-txt-bg'},"$0/month"),
          ),

         // body
          React.createElement('div',{className:'card-body p-3 text-start'},
          React.createElement('ul',{className:'text-start'},
          
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Single User")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," 50GB Storage")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Unlimited Public Projects")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Community Access")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-down"},), React.createElement('span',null," Unlimited Private Projects")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-down"},), React.createElement('span',null," Dedicated Phone Support")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-down"},), React.createElement('span',null," Free Subdomain")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-down"},), React.createElement('span',null," Monthly Status Reports")),
          )
          ),

           // footer

          React.createElement('div',{className:'card-footer bg-white p-3'},
          React.createElement('button',{className:'btn btn-primary'},"Button")
          ) 
          ),


          //card-2



         

          React.createElement('div',{id:'item1',className:'card p-0 m-0 '},
          
          // header

            React.createElement('div',{className:'card-header p-3 bg-white'}, 
            React.createElement('div',{id:'h-txt-sm'},"PLUS"),
            React.createElement('div',{id:'h-txt-bg'},"$9/month"),
          ),

         // body
          React.createElement('div',{className:'card-body p-3 text-start'},
          React.createElement('ul',{className:'text-start'},
          
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Single User")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," 50GB Storage")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Unlimited Public Projects")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Community Access")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Unlimited Private Projects")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Dedicated Phone Support")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Free Subdomain")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-down"},), React.createElement('span',null," Monthly Status Reports")),
          )
          ),

           // footer

          React.createElement('div',{className:'card-footer bg-white p-3'},
          React.createElement('button',{className:'btn btn-primary'},"Button")
          ) 
          ),

          //card-3

         

          React.createElement('div',{id:'item1',className:'card p-0 m-0 '},
          
          // header

            React.createElement('div',{className:'card-header p-3 bg-white'}, 
            React.createElement('div',{id:'h-txt-sm'},"PRO"),
            React.createElement('div',{id:'h-txt-bg'},"$49/month"),
          ),

         // body
          React.createElement('div',{className:'card-body p-3 text-start'},
          React.createElement('ul',{className:'text-start'},
          
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Single User")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," 50GB Storage")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Unlimited Public Projects")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Community Access")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Unlimited Private Projects")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Dedicated Phone Support")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Free Subdomain")),
               React.createElement('li',{id:'h-txt-md'}, React.createElement('span',{className:"fa fa-arrow-up"},), React.createElement('span',null," Monthly Status Reports")),
          )
          ),

           // footer

          React.createElement('div',{className:'card-footer bg-white p-3'},
          React.createElement('button',{className:'btn btn-primary'},"Button")
          ) 
          ),

  );
 

  
  
  

}

export default Price_Card