import React from "react";
import "./Card.css";
import { useState } from "react";

function Card() {
  
  //State

  const [itemCount, setItemCount] = useState(0);
  const [productData, setProductData] = useState([
    { pId: 1, pName: "Product1", pCart: true },
    { pId: 2, pName: "Product2", pCart: true },
    { pId: 3, pName: "Product3", pCart: true },
    { pId: 4, pName: "Product4", pCart: true },
    { pId: 5, pName: "Product5", pCart: true },
    { pId: 6, pName: "Product6", pCart: true },
  ]);

  //Function

  function changeStatusFalse(pItem) {
    var newItemData = setItemCount(itemCount + 1);

    var newCartData = productData.map((item) => {
      if (item.pId == pItem.pId) {
        item.pCart = false;
      }

      return item;
    });

    setProductData(newCartData);
  }

  function changeStatusTrue(pItem) {
    setItemCount(itemCount - 1);

    var newCartData = productData.map((item) => {
      if (item.pId == pItem.pId) {
        item.pCart = true;
      }

      return item;
    });

    setProductData(newCartData);
  }

  return (
    <>
      <div className="container">
        <div className="c1-1 d-flex justify-content-end">
          <button type="button" className="btn btn-dark p-1 m-1">
            Cart <span className="badge badge-light">{itemCount}</span>
          </button>
        </div>
      </div>

      {productData.map((pItem) => (
        <div className="card " key={pItem.pId}>
          <img className="card-img-top card-img"></img>
          <div className="card-body">
            <div className="card-title p-3 p-text">{pItem.pName}</div>

            {pItem.pCart ? (
              <button
                className="btn btn-primary p-1 m-2 p-text"
                onClick={() => changeStatusFalse(pItem)}
              >
                Add to cart
              </button>
            ) : (
              <button
                className="btn btn-primary p-1 m-2 p-text"
                onClick={() => changeStatusTrue(pItem)}
              >
                Remove cart
              </button>
            )}
          </div>
        </div>
      ))}
    </>
  );
}

export default Card;
