import React from "react";
import { useState } from "react";

function Practice() {
  //   const myListData = [
  //     { id: 1, name: "item1" },
  //     { id: 2, name: "item2" },
  //     { id: 3, name: "item3" },
  //   ];

  const [isClicked, setIsClicked] = useState(true);

  const [myListData, setMyListData] = useState([
    { id: 1, name: "item1" },
    { id: 2, name: "item2" },
    { id: 3, name: "item3" },
  ]);

  const handleRemove = (itemId) => {
    const updateMyList = myListData.filter((item) => item.id != itemId);
    // console.log(updateMyList);
    setMyListData(updateMyList);

    
    setIsClicked(false);
  };

  return (
    <div>
      {console.log("called")}

      <ol>
        {myListData.map((item) => (
          <li key={item.id}>
            {item.name}{"        "}
            <button onClick={() => handleRemove(item.id)}> Remove</button>
          </li>
        ))}
      </ol>
      {isClicked ? <button>Add to cart</button> : <button>Remove cart</button>}
    </div>
  );
}

export default Practice;
