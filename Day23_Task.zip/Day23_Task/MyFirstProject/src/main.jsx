import React from "react";
import ReactDOM from "react-dom/client";
// import App from './App.jsx'
// import './index.css'
import "./main.css";
import Card from "./Card";
import Practice from "./Practice";

ReactDOM.createRoot(document.getElementById("root")).render(
  // <React.StrictMode>

  <>
    {/* <App /> */}

    <div className="container-fluid c1 d-flex flex-row flex-wrap ">
      <Card></Card>
    </div>
    {/* <Practice></Practice> */}
  </>

  // </React.StrictMode>,
);
